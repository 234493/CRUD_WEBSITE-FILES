<?php
//create.php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {//Check it is coming from a form
		
		//mysql credentials
	$mysql_host = "localhost";
	$mysql_username = "charan8040";
	$mysql_password = "shakopeesabers1";
	$mysql_database = "Phones";
	
	$PhoneName = $_POST["PhoneName"];
	$Brand = $_POST["Brand"];
	$ReleaseDate = $_POST["ReleaseDate"];
	
	$mysqli = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
	
	if ($mysqli->connect_error) {
		die('Error : ('. $mysqli->connect_errno .') '. $mysqli->connect_error);
	}   
	
		$statement = $mysqli->prepare("INSERT INTO PhoneTable VALUES(?, ?, ?)"); //prepare sql insert query
		$statement->bind_param('sss', $PhoneName, $Brand, $ReleaseDate); //bind value
		if($statement->execute())
			{
				//print output text
				echo nl2br( $PhoneName. " " ."has been added to the table");
			}
			else{
					print $mysqli->error; //show mysql error if any 
				}

         }
else{
    echo ("error");
    }         
?>