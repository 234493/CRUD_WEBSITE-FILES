<?php
//read.php
$mysql_host = "localhost";
$mysql_username = "charan8040";
$mysql_password = "shakopeesabers1";
$mysql_database = "Phones";
$conn = new mysqli($mysql_host, $mysql_username, $mysql_password, $mysql_database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

	
$sql = "SELECT * FROM PhoneTable='" . $_POST['Brand'] . "'";
$result = $conn->query($sql);

$Phones= $row[0];
$PhoneName = $row[1];
$ReleaseDate = $row[2];
// HTML to display the form on this page.
echo"<HEAD> <link rel='stylesheet' href='styles.css'></HEAD><BODY>";
echo nl2br("<H2>Here is the roster for "." ". $_POST['Brand']."</H2>");
//$num_names = mysql_num_rows($roster_table);
if ($result->num_rows > 0)//will only do this if there is something to be returned from the above line
	{	echo"<HEAD> <link rel='stylesheet' href='styles.css'></HEAD>";
		echo "<TABLE><TR><TH>PhoneName</TH><TH>ReleaseDate</TH></TR>";
		// Iterate through all of the returned images, placing them in a table for easy viewing
	while($row = $result->fetch_assoc())
		{
			// The following few lines store information from specific cells in the data about an image
			echo "<TR>";
			echo "<TD>".$row['PhoneName']. "</TD><TD>"</TD><TD>".$row['year'] ."</TD>";
			echo "<TD><form action= 'update.php' method = 'post'>";
			echo "<button name = 'update'   type = 'submit' value =".$row['studentID'].">Edit</button></FORM>";
			echo "</TR>";
		}
	echo "</TABLE>";
	echo " <br> Need to update item?
	echo "<input name = 'action' type = 'submit' value = 'Yes';
	echo "<input name = 'action' type = 'submit' value = 'No';
	echo "</FORM>";
	}
	else{
		echo "<br> 0 results";
		}
        echo '</body>';
        
?>	